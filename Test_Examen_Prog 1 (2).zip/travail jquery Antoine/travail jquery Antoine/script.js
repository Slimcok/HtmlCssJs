/*
    Auteur : Antoine Girard ^._.^
    Date : 19 Novembre 2024
    Nom : Travail Pratique 4
    But : Faire Ajouter des références à des élément <a> avec JQuerry et JS.
*/ 

document.addEventListener("DOMContentLoaded", function () {
    // Récupérer tous les <a> avec .piedpage
    const piedpages = document.querySelectorAll("a.piedpage");
    const body = document.body;

    // Créer #refcan 
    let refcan = document.createElement("div");
    refcan.id = "refcan";
    body.appendChild(refcan);

    // Parcourir tous les liens et ajouter leurs références
    piedpages.forEach((piedpage, index) => {
        const note = piedpage.getAttribute("data-note"); // Récupérer la note
        const refNumber = index + 1; // Numéro de référence

        // Ajouter un <sup> avec le numéro de référence après le lien
        const sup = document.createElement("sup");
        sup.textContent = refNumber;
        piedpage.after(sup);

        // Ajouter la note correspondante dans #refcan
        const noteElement = document.createElement("p");
        noteElement.textContent = `${refNumber}. ${note}`;
        refcan.appendChild(noteElement);
    });
});
