/**
 * Auteur : Antoine Girard
 * Travail : TP3
 * Date : 11/12/2024
 * But : Faire une table qui contient Auteur, Titre et ISBN d'livre. Puis les enregistrer dans localStorage.
 * Etre capable de Supprimer les lignes avec un bouton
 */

let livres = JSON.parse(localStorage.getItem("livres")) || [];

/**
 * Affiche un message dans la boîte de message avec un type spécifique (succès ou erreur)
 */
function afficherMessage(message, type) {
    const boiteMessage = document.getElementById('boite-message');
    boiteMessage.textContent = message;
    boiteMessage.className = `boite-message ${type}`; // Applique la classe succès ou erreur
    boiteMessage.style.display = 'block';

    // Réinitialise le timer s'il existe
    if (messageTimeout) {
        clearTimeout(messageTimeout);
    }

    // Cache le message après 3 secondes
    messageTimeout = setTimeout(() => {
        boiteMessage.style.display = 'none';
    }, 3000);
}

/**
 * Affiche les livres dans livres = JSON.parse(localStorage.getItem("livres")) || []
 */
function afficherLivres() {
    const tbodyRef = document.getElementById('livres').getElementsByTagName('tbody')[0];
    
    // Efface toutes les lignes existantes dans le tbody
    tbodyRef.innerHTML = '';

    livres.forEach(livre => {
        const newRow = tbodyRef.insertRow();

        // Crée une cellule pour chaque information du livre
        livre.forEach(info => {
            const newCell = newRow.insertCell();
            newCell.appendChild(document.createTextNode(info));
        });

        // Ajoute le bouton de suppression
        const deleteCell = newRow.insertCell();
        const deleteBtn = document.createElement('button');
        deleteBtn.textContent = 'X';
        deleteBtn.className = 'btn btn-danger btn-sm';

        // Écouteur pour supprimer le livre
        deleteBtn.addEventListener('click', () => {
            tbodyRef.removeChild(newRow); 
            livres = livres.filter(l => l[2] !== livre[2]); 
            localStorage.setItem("livres", JSON.stringify(livres));
            afficherMessage("Livre supprimé avec succès.", "succes");
        });
        deleteCell.appendChild(deleteBtn);
    });
}

/**
 * Ajoute une nouvelle ligne de livre dans la table si les informations sont valides
 */
function ajouterLigne() {
    const auteur = document.getElementById('auteur').value.trim();
    const titre = document.getElementById('titre').value.trim();
    const isbn = document.getElementById('isbn').value.trim();

    // Vérifie si tous les champs sont remplis
    if (auteur && titre && isbn) {
        // Vérifie si l'ISBN existe déjà
        const doublon = livres.some(livre => livre[2] === isbn);
        if (doublon) {
            afficherMessage("Ce livre avec cet ISBN existe déjà.", "erreur");
            return;
        }

        // Ajoute le livre à la liste
        const livre = [auteur, titre, isbn];
        livres.push(livre);
        localStorage.setItem("livres", JSON.stringify(livres));

        afficherLivres();

        // Réinitialise les champs et affiche le message de succès
        document.getElementById('auteur').value = '';
        document.getElementById('titre').value = '';
        document.getElementById('isbn').value = '';
        afficherMessage("Livre ajouté avec succès.", "succes");
        
    } else {
        afficherMessage("Veuillez remplir tous les champs.", "erreur");
    }
}

// Ajoute un écouteur d'événements pour le bouton d'ajout
document.getElementById('btn-ajouter').addEventListener('click', ajouterLigne);

// Appelle la fonction pour afficher les livres enregistrés lors du chargement de la page
window.onload = afficherLivres;
