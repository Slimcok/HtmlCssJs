<?php /*
Auteur : Antoine Girard
Date : 11/27/2024
Nom : TP5
But : Faire un moteur de recherche pour une base de données des communes de france avec AJAX, JQuerry et PHP
Connexion : http://10.10.211.31/tp5/page.html
*/
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=utf-8");

// Activer le rapport d'erreurs
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Connexion à la base de données
$serveur = "localhost";
$utilisateur = "root";
$motDePasse = "";
$nomBDD = "communes";

$conn = new mysqli($serveur, $utilisateur, $motDePasse, $nomBDD);

if ($conn->connect_error) {
    echo json_encode(["error" => "Connexion à la base de données échouée"]);
    exit;
}

$conn->set_charset("utf8mb4");

// Si un nom de commune est fourni
if (isset($_GET['commune'])) {
    $nomCommune = $conn->real_escape_string($_GET['commune']);
    $sql = "SELECT * FROM communes WHERE nom = '$nomCommune' LIMIT 1";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        $data = $result->fetch_assoc();
    } else {
        $data = ["error" => "Commune introuvable"];
    }
    echo json_encode($data);
    exit;
}

// Si une recherche est effectuée
if (isset($_GET['query'])) {
    $query = $conn->real_escape_string($_GET['query']);
    $sql = "SELECT num1, num2, nom FROM communes WHERE nom LIKE '$query%' LIMIT 10";
    $result = $conn->query($sql);

    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
    echo json_encode($data);
    exit;
}

echo json_encode(["error" => "Requête invalide"]);
$conn->close();
?>
