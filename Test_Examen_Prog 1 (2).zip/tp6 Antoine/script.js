/*
Auteur : Antoine Girard
Date : 11/27/2024
Nom : TP5
But : Faire un moteur de recherche pour une base de données des communes de france avec AJAX, JQuerry et PHP
Connexion : http://10.10.211.31/tp5/page.html
*/

const barreRecherche = document.querySelector("#barre-recherche");
const listeResultats = document.querySelector("#liste-resultats");
const conteneurDetails = document.querySelector("#conteneur-details");

let resultats = []; // Stocke les résultats pour un accès facile

// Fonction pour afficher les détails d'une commune
function afficherDetails(commune) {
    console.log("Afficher les détails pour :", commune);
    fetch(`http://10.10.211.31/connectionBD.php?commune=${encodeURIComponent(commune)}`)
        .then(response => {
            if (!response.ok) {
                throw new Error("Erreur réseau lors de la récupération des détails.");
            }
            return response.json();
        })
        .then(details => {
            console.log("Détails reçus :", details);
            if (details.error) {
                conteneurDetails.innerHTML = `<p>${details.error}</p>`;
            } else {
                conteneurDetails.innerHTML = `
                    <h2>Détails de la commune</h2>
                    <p><strong>Département :</strong> ${details.num1}</p>
                    <p><strong>Code :</strong> ${details.num2}</p>
                    <p><strong>Nom :</strong> ${details.nom}</p>
                    <p><strong>Nom Majuscule :</strong> ${details.nom_maj}</p>
                    <p><strong>Nom Minuscule :</strong> ${details.nom_min}</p>
                    <p><strong>Code Postal :</strong> ${details.num3}</p>
                `;
            }
        })
        .catch(error => {
            console.error("Erreur lors de la récupération des détails :", error);
        });
}

// Écoute les saisies dans la barre de recherche
barreRecherche.addEventListener("input", () => {
    const requete = barreRecherche.value.trim();
    console.log("Recherche pour :", requete);

    if (requete.length > 0) {
        fetch(`http://10.10.211.31/connectionBD.php?query=${encodeURIComponent(requete)}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error("Erreur réseau lors de la récupération des résultats.");
                }
                return response.json();
            })
            .then(data => {
                console.log("Résultats reçus :", data);
                resultats = data; // Stocke les résultats pour une utilisation ultérieure
                listeResultats.innerHTML = "";

                if (data.length === 0) {
                    listeResultats.innerHTML = `<li>Aucune commune trouvée</li>`;
                } else {
                    data.forEach(row => {
                        const elementListe = document.createElement("li");
                        // Affiche le nom suivi des numéros, séparés par des virgules
                        elementListe.textContent = `${row.nom}, ${row.num1}, ${row.num2}`;
                        elementListe.addEventListener("click", () => {
                            afficherDetails(row.nom);
                            barreRecherche.value = row.nom;
                            listeResultats.innerHTML = ""; // Vide la liste des résultats après un clic
                        });
                        listeResultats.appendChild(elementListe);
                    });
                }
            })
            .catch(error => {
                console.error("Erreur lors de la récupération des résultats :", error);
            });
    } else {
        console.log("Réinitialisation des résultats.");
        resultats = [];
        listeResultats.innerHTML = "";
        conteneurDetails.innerHTML = "";
    }
});

// Écoute la touche "Entrée"
barreRecherche.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
        event.preventDefault(); // Empêche le comportement par défaut
        if (resultats.length > 0) {
            console.log("Entrée détectée. Affichage du premier résultat.");
            afficherDetails(resultats[0].nom); // Affiche les détails du premier résultat
            listeResultats.innerHTML = ""; // Vide la liste des résultats
        } else {
            console.log("Aucun résultat trouvé.");
            conteneurDetails.innerHTML = `<p>Aucun résultat trouvé pour "${barreRecherche.value}".</p>`;
        }
    }
});
